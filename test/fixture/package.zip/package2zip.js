'use strict';

var tar2zip = require('tar-to-zip');

module.exports = function package2zip(pack) {
    var hasDist = checkForDist(pack);

    return tar2zip(pack, {
        filter: hasDist ? distFilter : packageFilter,
        map: hasDist ? distMap : packageMap
    }).getStream();
};

function checkForDist(pack) {
    return false;
}

function distFilter(fileHeader) {
    return name.substr(0, 13) === 'package/dist/';
}

function distMap(fileHeader) {
    return {
        name: fileHeader.name.substr(13)
    };
}

function packageFilter(fileHeader) {
    return name.substr(0, 8) === 'package/';
}

function packageMap(fileHeader) {
    return {
        name: fileHeader.name.substr(8)
    };
}